<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/ico" href="https://ltyun.top/favicon/favicon.ico">
    <title>用户创建</title>
    <link href="./ui/css/bootstrap.min.css" rel="stylesheet">
<link href="./ui/css/materialdesignicons.min.css" rel="stylesheet">
<link rel="stylesheet" href="./ui/js/jconfirm/jquery-confirm.min.css">
<link href="./ui/css/style.min.css" rel="stylesheet">

</head>
<style>
    body, html {
        height: 100%;
        margin: 0;
    }
    body {
    padding: 0;
    font-family: Arial, sans-serif;
    background-size: cover;
}
body {
    background-image: url('https://ltyun.top/1img/boats-564922_1280.jpg'); 
            background-size: 120%;
            background-attachment: fixed;
        }
        
     
        @media only screen and (max-width: 600px) {
            body {
                background-size: cover;
        
            }
        }
    .full-height {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100%;
    }

    .card {
        width: 100%;
        max-width: 500px;
        box-sizing: border-box;
        padding: 20px;
    }

    .form-control {
        width: 100%;
        box-sizing: border-box;
        padding: 10px;
        margin-bottom: 10px;
        position: relative;
    }

    .captcha-container {
        position: relative;
        width: 100%;
    }

    .captcha-input {
        padding-right: 90px; 
    }

    .captcha-image {
        position: absolute;
        right: 10px; 
        top: 50%;
        transform: translateY(-50%);
        cursor: pointer;
        border-radius: 2px;
        width: 80px;
        height: 30px;
    }

    .btn {
        display: inline-block;
        padding: 10px 20px;
        text-align: center;
        cursor: pointer;
    }

    .container {
        width: 100%;
        padding: 0 10px;
        box-sizing: border-box;
    }
    .card {
    width: 100%;
    max-width: 500px;
    box-sizing: border-box;
    padding: 20px;
    background-color: rgba(255, 255, 255, 0.5);
    backdrop-filter: blur(10px); 
}

</style>
<body>
    <div class="full-height">
        <div class="card">
            <div class="card-body">
                <div class="container">
                    <img src="https://ltyun.top/1img/lt.png">
                    <h1>创建 Windows 用户</h1>
                    <form id="userForm">
                        <label for="username">用户名:</label>
                        <input type="text" id="username" name="username" required class="form-control">
                        <label for="password">密码:</label>
                        <input type="password" id="password" name="password" required class="form-control">
                        <label for="captcha">验证码:</label>
                        <div class="captcha-container">
                            <input type="text" id="captcha" name="captcha" required class="form-control captcha-input">
                            <img src="captcha.php" id="captchaImage" alt="验证码" onclick="this.src='captcha.php?' + new Date().getTime();" class="captcha-image">
                        </div>
                        
                        <button type="submit" class="btn btn-info">创建用户</button>
                    </form><br>
                    <a>由 蓝天新世界 提供开源技术</a>
                   <!-- <div id="response"></div>--><!--旧版-->
                </div>
                
            </div>
        </div>
    </div>
</body>

</body>
<script>
document.getElementById('userForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const captcha = document.getElementById('captcha').value;
    fetch('create_user.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
            'username': username,
            'password': password,
            'captcha': captcha
        })
    })
    .then(response => response.text())
    .then(data => {
        $.confirm({
            title: '服务器响应',
            content: data,
            buttons: {
                confirm: {
                    text: '好！',
                    action: function () {
                        document.getElementById('captchaImage').src = 'captcha.php?' + new Date().getTime();
                    }
                }
            }
        });
    })
    .catch(error => {
        $.confirm({
            title: '错误',
            content: '发生错误: ' + error,
            buttons: {
                confirm: {
                    text: '确定！',
                    action: function () {
                        document.getElementById('captchaImage').src = 'captcha.php?' + new Date().getTime();
                    }
                }
            }
        });
    });
});

</script><!---旧版-->
   <!-- <script>
        document.getElementById('userForm').addEventListener('submit', function(event) {
            event.preventDefault();
            
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const captcha = document.getElementById('captcha').value;
            fetch('create_user.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    'username': username,
                    'password': password,
                    'captcha': captcha
                })
            })
            .then(response => response.text())
            .then(data => {
                document.getElementById('response').innerText = data;
                document.getElementById('captchaImage').src = 'captcha.php?' + new Date().getTime();
                
            })
            .catch(error => {
                document.getElementById('response').innerText = '发生错误: ' + error;
                document.getElementById('captchaImage').src = 'captcha.php?' + new Date().getTime();
            });
        });
    </script>-->
</body>
</html>
<script type="text/javascript" src="./ui/js/jquery.min.js"></script>
<script type="text/javascript" src="./ui/js/bootstrap.min.js"></script>
<script type="text/javascript" src="./ui/js/perfect-scrollbar.min.js"></script>
<!--对话框-->
<script src="./ui/js/jconfirm/jquery-confirm.min.js"></script>
<script type="text/javascript" src="./ui/js/main.min.js"></script>