<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   
    $username =$_POST['username'];
    $password =$_POST['password'];
    $captcha =$_POST['captcha'];

    function validateCaptcha($captcha) {
   
        if (!isset($_SESSION['captcha'])) {
            return false;
        }
    
        if (strtolower($captcha) === strtolower($_SESSION['captcha'])) {
          
            unset($_SESSION['captcha']);
            return true;
        }
    
        return false;
    }

    if (empty($username) || empty($password)) {
        echo '用户名或密码不能为空';
        exit;
    }


    if (strlen($username) > 10) {
        echo '用户名不能超过10个字符';
        exit;
    }


    if (!validateCaptcha($captcha)) {
        echo '验证码错误';
        exit; 
    }


    if (strpos($username, 'admin') !== false || strpos($username, 'root') !== false || strpos($username, 'administrator') !== false || strpos($username, 'Administrator') !== false) {
        echo '用户名包含非法字符';
        exit;
    }

    $commandCheckUser = "net user \"$username\" 2>&1";
    $outputCheckUser = [];
    $return_varCheckUser = 0;
    exec($commandCheckUser,$outputCheckUser, $return_varCheckUser);


    foreach ($outputCheckUser as$line) {
   
        $line = iconv('GBK', 'UTF-8',$line);
        if (strpos($line, '用户账户') !== false && strpos($line, '已经存在') !== false) {
            echo '用户名已存在';
            exit;
        }
    }


    $command = "net user \"$username\" \"$password\" /add 2>&1"; 

    
    $output = [];
    $return_var = 0;
    exec($command,$output, $return_var);

   
    if ($return_var === 0) {
        echo '用户创建成功';
    } else {
       
        echo '创建用户失败，错误信息：' . PHP_EOL;
        if (empty($output)) {
            echo '没有捕获到错误信息。可能是因为命令执行失败或没有权限。';
        } else {
            foreach ($output as$line) {
                echo iconv('GBK', 'UTF-8', $line) . PHP_EOL;
            }
        }
    }
} else {
    echo '无效的请求方法';
}
